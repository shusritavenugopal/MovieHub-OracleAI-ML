prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7266698827421149
,p_default_application_id=>100
,p_default_id_offset=>8541228906651295
,p_default_owner=>'WKSP_HEATWAVE'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Hello, Lisa'
,p_alias=>'HELLO-LISA'
,p_step_title=>'Hello, Lisa'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-tags {',
'    list-style: lower-latin ;',
'}',
'.a-tag {',
'    background-color: #0b080e;',
'    color: rgb(248, 248, 248);',
'    border-radius: 8px;',
'    padding: 6px;',
'    margin: 5px;',
'    display: inline-flex;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'HEATWAVE'
,p_last_upd_yyyymmddhh24miss=>'20231025074645'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10385740773751201)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16670965546600409)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16555259918600334)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16733428132600444)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36856223787883992)
,p_plug_name=>'Recommended Movies For You'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16658618210600400)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32242247065048910)
,p_plug_name=>'User 20 + 15r'
,p_region_name=>'U20_15'
,p_parent_plug_id=>wwv_flow_imp.id(36856223787883992)
,p_region_template_options=>'u-colors:t-CardsRegion--styleA:js-headingLevel-2:t-Form--slimPadding:t-Form--large:t-Form--leftLabels:t-Form--labelsAbove'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16594788254600370)
,p_plug_display_sequence=>40
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    q.item_id,',
'    q.Title,',
'    q.`Release Year`,',
'    TRIM('','' FROM q.Genres) AS Genres,',
'    m.user_id,',
'    m.ml_results AS ''Recommendation Rating'',',
'    u.url_down,',
'    i.legend',
'FROM movies.pred_user_20_15r m',
'JOIN (',
'    SELECT',
'        item_id,',
'        title AS ''Title'',',
'        release_year AS ''Release Year'',',
'        CONCAT(',
'            IF(genre_action = 1, CONCAT(''action,''), CONCAT('''')),',
'            IF(genre_adventure = 1, CONCAT(''adventure,''), CONCAT('''')),',
'            IF(genre_animation = 1, CONCAT(''animation,''), CONCAT('''')),',
'            IF(genre_children = 1, CONCAT(''children,''), CONCAT('''')),',
'            IF(genre_comedy = 1, CONCAT(''comedy,''), CONCAT('''')),',
'            IF(genre_crime = 1, CONCAT(''crime,''), CONCAT('''')),',
'            IF(genre_documentary = 1, CONCAT(''documentary,''), CONCAT('''')),',
'            IF(genre_drama = 1, CONCAT(''drama,''), ''''),',
'            IF(genre_fantasy = 1, CONCAT(''fantasy,''), CONCAT('''')),',
'            IF(genre_filmnoir = 1, CONCAT(''filmnoir,''), CONCAT('''')),',
'            IF(genre_horror = 1, CONCAT(''horror,''), CONCAT('''')),',
'            IF(genre_musical = 1, CONCAT(''musical,''), CONCAT('''')),',
'            IF(genre_mystery = 1, CONCAT(''mystery,''), CONCAT('''')),',
'            IF(genre_romance = 1, CONCAT(''romance,''), CONCAT('''')),',
'            IF(genre_scifi = 1, CONCAT(''scifi,''), CONCAT('''')),',
'            IF(genre_thriller = 1, CONCAT(''thriller,''), CONCAT('''')),',
'            IF(genre_unknown = 1, CONCAT(''unknown,''), CONCAT('''')),',
'            IF(genre_war = 1, CONCAT(''war,''), CONCAT('''')),',
'            IF(genre_western = 1, CONCAT(''western,''), CONCAT(''''))',
'        ) AS ''Genres''',
'    FROM movies.item',
') q ON m.item_id = q.item_id',
'JOIN item_media u ON m.item_id = u.image_id',
'JOIN (',
'    SELECT image_id, legend',
'    FROM item_media',
') i ON m.item_id = i.image_id',
'ORDER BY m.ml_results DESC, q.Title DESC',
'LIMIT 5;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(8603857617610164)
,p_region_id=>wwv_flow_imp.id(32242247065048910)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3><b>&"Title".</b></h3>'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'Release Year'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'{if Genres/}',
'    <ul class="a-tags">',
'    {loop "," Genres/}',
' 	    <li class="a-tag"><b>&APEX$ITEM.</li></b>',
'    {endloop/}',
'    </ul>',
'{endif/}',
'</br>'))
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<h4><b>&"legend".</b></h4>'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'url_down'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'Genres'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32242472857048912)
,p_plug_name=>'User 20 + 30r'
,p_region_name=>'U20_30'
,p_parent_plug_id=>wwv_flow_imp.id(36856223787883992)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleA:js-headingLevel-1:t-Form--slimPadding:t-Form--large:t-Form--leftLabels:t-Form--labelsAbove'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16594788254600370)
,p_plug_display_sequence=>50
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    q.item_id,',
'    q.Title,',
'    q.`Release Year`,',
'    TRIM('','' FROM q.Genres) AS Genres,',
'    m.user_id,',
'    m.ml_results AS ''Recommendation Rating'',',
'    u.url_down,',
'    i.legend',
'FROM movies.pred_user_20_30r m',
'JOIN (',
'    SELECT',
'        item_id,',
'        title AS ''Title'',',
'        release_year AS ''Release Year'',',
'        CONCAT(',
'            IF(genre_action = 1, CONCAT(''action,''), CONCAT('''')),',
'            IF(genre_adventure = 1, CONCAT(''adventure,''), CONCAT('''')),',
'            IF(genre_animation = 1, CONCAT(''animation,''), CONCAT('''')),',
'            IF(genre_children = 1, CONCAT(''children,''), CONCAT('''')),',
'            IF(genre_comedy = 1, CONCAT(''comedy,''), CONCAT('''')),',
'            IF(genre_crime = 1, CONCAT(''crime,''), CONCAT('''')),',
'            IF(genre_documentary = 1, CONCAT(''documentary,''), CONCAT('''')),',
'            IF(genre_drama = 1, CONCAT(''drama,''), ''''),',
'            IF(genre_fantasy = 1, CONCAT(''fantasy,''), CONCAT('''')),',
'            IF(genre_filmnoir = 1, CONCAT(''filmnoir,''), CONCAT('''')),',
'            IF(genre_horror = 1, CONCAT(''horror,''), CONCAT('''')),',
'            IF(genre_musical = 1, CONCAT(''musical,''), CONCAT('''')),',
'            IF(genre_mystery = 1, CONCAT(''mystery,''), CONCAT('''')),',
'            IF(genre_romance = 1, CONCAT(''romance,''), CONCAT('''')),',
'            IF(genre_scifi = 1, CONCAT(''scifi,''), CONCAT('''')),',
'            IF(genre_thriller = 1, CONCAT(''thriller,''), CONCAT('''')),',
'            IF(genre_unknown = 1, CONCAT(''unknown,''), CONCAT('''')),',
'            IF(genre_war = 1, CONCAT(''war,''), CONCAT('''')),',
'            IF(genre_western = 1, CONCAT(''western,''), CONCAT(''''))',
'        ) AS ''Genres''',
'    FROM movies.item',
') q ON m.item_id = q.item_id',
'JOIN item_media u ON m.item_id = u.image_id',
'JOIN (',
'    SELECT image_id, legend',
'    FROM item_media',
') i ON m.item_id = i.image_id',
'ORDER BY m.ml_results DESC, q.Title DESC',
'LIMIT 5;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(8604708646610165)
,p_region_id=>wwv_flow_imp.id(32242472857048912)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3><b>&"Title".</b></h3>'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'Release Year'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'{if Genres/}',
'    <ul class="a-tags">',
'    {loop "," Genres/}',
' 	    <li class="a-tag"><b>&APEX$ITEM.</li></b>',
'    {endloop/}',
'    </ul>',
'{endif/}',
'</br>'))
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<h4><b>&"legend".</b></h4>'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'url_down'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'Genres'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34051920645274367)
,p_plug_name=>'User 20 + 0r'
,p_region_name=>'U20_0'
,p_parent_plug_id=>wwv_flow_imp.id(36856223787883992)
,p_region_template_options=>'u-colors:t-CardsRegion--styleA:js-headingLevel-1:t-Form--slimPadding:t-Form--large:t-Form--leftLabels:t-Form--labelsAbove:t-Region-orderBy--center'
,p_plug_template=>wwv_flow_imp.id(16594788254600370)
,p_plug_display_sequence=>30
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    q.item_id,',
'    q.Title,',
'    q.`Release Year`,',
'    TRIM('','' FROM q.Genres) AS Genres,',
'    m.user_id,',
'    m.ml_results AS ''Recommendation Rating'',',
'    u.url_down,',
'    i.legend',
'FROM movies.pred_user_20_0r m',
'JOIN (',
'    SELECT',
'        item_id,',
'        title AS ''Title'',',
'        release_year AS ''Release Year'',',
'        CONCAT(',
'            IF(genre_action = 1, CONCAT(''action,''), CONCAT('''')),',
'            IF(genre_adventure = 1, CONCAT(''adventure,''), CONCAT('''')),',
'            IF(genre_animation = 1, CONCAT(''animation,''), CONCAT('''')),',
'            IF(genre_children = 1, CONCAT(''children,''), CONCAT('''')),',
'            IF(genre_comedy = 1, CONCAT(''comedy,''), CONCAT('''')),',
'            IF(genre_crime = 1, CONCAT(''crime,''), CONCAT('''')),',
'            IF(genre_documentary = 1, CONCAT(''documentary,''), CONCAT('''')),',
'            IF(genre_drama = 1, CONCAT(''drama,''), ''''),',
'            IF(genre_fantasy = 1, CONCAT(''fantasy,''), CONCAT('''')),',
'            IF(genre_filmnoir = 1, CONCAT(''filmnoir,''), CONCAT('''')),',
'            IF(genre_horror = 1, CONCAT(''horror,''), CONCAT('''')),',
'            IF(genre_musical = 1, CONCAT(''musical,''), CONCAT('''')),',
'            IF(genre_mystery = 1, CONCAT(''mystery,''), CONCAT('''')),',
'            IF(genre_romance = 1, CONCAT(''romance,''), CONCAT('''')),',
'            IF(genre_scifi = 1, CONCAT(''scifi,''), CONCAT('''')),',
'            IF(genre_thriller = 1, CONCAT(''thriller,''), CONCAT('''')),',
'            IF(genre_unknown = 1, CONCAT(''unknown,''), CONCAT('''')),',
'            IF(genre_war = 1, CONCAT(''war,''), CONCAT('''')),',
'            IF(genre_western = 1, CONCAT(''western,''), CONCAT(''''))',
'        ) AS ''Genres''',
'    FROM movies.item',
') q ON m.item_id = q.item_id',
'JOIN item_media u ON m.item_id = u.image_id',
'JOIN (',
'    SELECT image_id, legend',
'    FROM item_media',
') i ON m.item_id = i.image_id',
'ORDER BY m.ml_results DESC, q.Title DESC',
'LIMIT 5;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(8602003579610162)
,p_region_id=>wwv_flow_imp.id(34051920645274367)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3><b>&"Title".</b></h3>'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'Release Year'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'{if Genres/}',
'    <ul class="a-tags">',
'    {loop "," Genres/}',
' 	    <li class="a-tag"><b>&APEX$ITEM.</li></b>',
'    {endloop/}',
'    </ul>',
'{endif/}',
'</br>'))
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<h4><b>&"legend".</b></h4>'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'url_down'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'Genres'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60770314217993280)
,p_plug_name=>'Popular Movies'
,p_region_name=>'POP4'
,p_parent_plug_id=>wwv_flow_imp.id(36856223787883992)
,p_region_template_options=>'u-colors:t-CardsRegion--styleA:js-headingLevel-1:t-Form--slimPadding:t-Form--large:t-Form--leftLabels:t-Form--labelsAbove:t-Region-orderBy--center'
,p_plug_template=>wwv_flow_imp.id(16594788254600370)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    q.item_id,',
'    q.Title,',
'    q.`Release Year`,',
'    TRIM('','' FROM q.Genres) AS Genres,',
'    m.user_id,',
'    m.ml_results AS ''Recommendation Rating'',',
'    u.url_down,',
'    i.legend',
'FROM movies.pred_user_new_30r m',
'JOIN (',
'    SELECT',
'        item_id,',
'        title AS ''Title'',',
'        release_year AS ''Release Year'',',
'        CONCAT(',
'            IF(genre_action = 1, CONCAT(''action,''), CONCAT('''')),',
'            IF(genre_adventure = 1, CONCAT(''adventure,''), CONCAT('''')),',
'            IF(genre_animation = 1, CONCAT(''animation,''), CONCAT('''')),',
'            IF(genre_children = 1, CONCAT(''children,''), CONCAT('''')),',
'            IF(genre_comedy = 1, CONCAT(''comedy,''), CONCAT('''')),',
'            IF(genre_crime = 1, CONCAT(''crime,''), CONCAT('''')),',
'            IF(genre_documentary = 1, CONCAT(''documentary,''), CONCAT('''')),',
'            IF(genre_drama = 1, CONCAT(''drama,''), ''''),',
'            IF(genre_fantasy = 1, CONCAT(''fantasy,''), CONCAT('''')),',
'            IF(genre_filmnoir = 1, CONCAT(''filmnoir,''), CONCAT('''')),',
'            IF(genre_horror = 1, CONCAT(''horror,''), CONCAT('''')),',
'            IF(genre_musical = 1, CONCAT(''musical,''), CONCAT('''')),',
'            IF(genre_mystery = 1, CONCAT(''mystery,''), CONCAT('''')),',
'            IF(genre_romance = 1, CONCAT(''romance,''), CONCAT('''')),',
'            IF(genre_scifi = 1, CONCAT(''scifi,''), CONCAT('''')),',
'            IF(genre_thriller = 1, CONCAT(''thriller,''), CONCAT('''')),',
'            IF(genre_unknown = 1, CONCAT(''unknown,''), CONCAT('''')),',
'            IF(genre_war = 1, CONCAT(''war,''), CONCAT('''')),',
'            IF(genre_western = 1, CONCAT(''western,''), CONCAT(''''))',
'        ) AS ''Genres''',
'    FROM movies.item',
') q ON m.item_id = q.item_id',
'JOIN item_media u ON m.item_id = u.image_id',
'JOIN (',
'    SELECT image_id, legend',
'    FROM item_media',
') i ON m.item_id = i.image_id',
'ORDER BY m.ml_results DESC, q.Title DESC',
'LIMIT 5;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(8602946146610163)
,p_region_id=>wwv_flow_imp.id(60770314217993280)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3><b>&"Title".</b></h3>'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'Release Year'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'{if Genres/}',
'    <ul class="a-tags">',
'    {loop "," Genres/}',
' 	    <li class="a-tag"><b>&APEX$ITEM.</li></b>',
'    {endloop/}',
'    </ul>',
'{endif/}',
'</br>'))
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<h4><b>&"legend".</b></h4>'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'url_down'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'Genres'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8599179051610031)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(36856223787883992)
,p_button_name=>'LOGOUT941'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--warning:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(16731741709600443)
,p_button_is_hot=>'Y'
,p_button_image_alt=>']-> Profiles'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8599571709610159)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(36856223787883992)
,p_button_name=>'ADD15'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16731741709600443)
,p_button_image_alt=>'Watch 15 Movies'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8599881750610160)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(36856223787883992)
,p_button_name=>'ADD30'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16731741709600443)
,p_button_image_alt=>'Watch 30 Movies'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8600272128610160)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(36856223787883992)
,p_button_name=>'Restore'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16731741709600443)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Restore'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36858867134884127)
,p_name=>'DATE_4'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(36856223787883992)
,p_item_display_point=>'EDIT'
,p_item_default=>'SELECT TO_CHAR(sysdate, ''YYYY-MM-DD'') FROM dual;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Login Date'
,p_format_mask=>'YYYY-MM-DD'
,p_source=>'SELECT TO_CHAR(sysdate, ''YYYY-MM-DD'') FROM dual;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16729275947600439)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'NATIVE'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'P4_SYSDATE'
,p_attribute_06=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37779826629771829)
,p_name=>'P4_SYSDATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(36856223787883992)
,p_item_display_point=>'EDIT'
,p_use_cache_before_default=>'NO'
,p_item_default=>'SELECT TO_CHAR(sysdate, ''YYYY-MM-DD'') FROM dual;'
,p_item_default_type=>'SQL_QUERY'
,p_source=>'SELECT TO_CHAR(sysdate, ''YYYY-MM-DD'') FROM dual;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37780253356771833)
,p_name=>'P4_SESSION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(36856223787883992)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39255727088145240)
,p_name=>'P4_ACK'
,p_item_sequence=>40
,p_item_display_point=>'REGION_POSITION_05'
,p_use_cache_before_default=>'NO'
,p_prompt=>'Acknowledgement'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'F. Maxwell Harper and Joseph A. Konstan. 2015. The MovieLens Datasets:',
'History and Context. ACM Transactions on Interactive Intelligent Systems (TiiS) 5, 4, Article 19 (December 2015), 19 pages.',
'DOI=http://dx.doi.org/10.1145/2827872'))
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(16729275947600439)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8606396991610174)
,p_name=>'add 15'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8599571709610159)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8606892266610174)
,p_event_id=>wwv_flow_imp.id(8606396991610174)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#U20_0").hide(10);',
'$("#U20_30").hide(10);',
'$("#U20_15").show(10);',
'$("#POP4").hide(10);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8607305679610174)
,p_name=>'add 30'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8599881750610160)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8607847906610175)
,p_event_id=>wwv_flow_imp.id(8607305679610174)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#U20_0").hide(10);',
'$("#U20_15").hide(10);',
'$("#U20_30").show(10);',
'$("#POP4").hide(10);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8608185355610175)
,p_name=>'Restore'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8600272128610160)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8608749422610175)
,p_event_id=>wwv_flow_imp.id(8608185355610175)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#U20_15").hide(10);',
'$("#U20_30").hide(10);',
'$("#U20_0").show(10);',
'$("#POP4").hide(10);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8609063216610175)
,p_name=>'restore'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8609569812610176)
,p_event_id=>wwv_flow_imp.id(8609063216610175)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#U20_15").hide(10);',
'$("#U20_30").hide(10);',
'$("#U20_0").show(10);',
'$("#POP4").hide(10);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8610042498610176)
,p_name=>'session2'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8599571709610159)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8610507126610176)
,p_event_id=>wwv_flow_imp.id(8610042498610176)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_SESSION'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'2'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8610881385610176)
,p_name=>'session3'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8599881750610160)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8611406629610176)
,p_event_id=>wwv_flow_imp.id(8610881385610176)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_SESSION'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'3'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8611838558610177)
,p_name=>'session1'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8600272128610160)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8612317031610177)
,p_event_id=>wwv_flow_imp.id(8611838558610177)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_SESSION'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8612739733610177)
,p_name=>'New'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'DATE_4'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8613201893610177)
,p_event_id=>wwv_flow_imp.id(8612739733610177)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// **Get the date string from the input type',
'',
'var itemVal = $v(''DATE_4'');',
'//var itemVal = "2023-09-26"',
'',
'// **Get the various element of the date ie year, month and date',
'',
'',
'var year = itemVal.substring(0,4);  ',
'',
'var month = itemVal.substring(5,7);  ',
'',
'var day = itemVal.substring(8,10);',
'',
'// **Construct JS Date Object  ',
'console.log(''The DatePicked date is: '' + itemVal);',
'console.log(''The year date is: '' + year);',
'console.log(''The month date is: '' + month);',
'console.log(''The day date is: '' + day);',
'',
'var inputDate =new Date();  ',
'',
'inputDate.setFullYear(year,month-1,day);  //Months in javascript start from 0',
'',
'inputDate.setHours(0,0,0,0);',
'',
'console.log(''The input date is: '' + inputDate);',
'// **Get todays date, as Date Object  ',
'',
'var todayDate = new Date(); ',
'',
'todayDate.setHours(0,0,0,0);',
'',
'console.log(''The todays date is: '' + todayDate);',
'',
'var todayPlus31 =new Date();  ',
'',
'todayPlus31 = apex.date.add( todayPlus31, 31, apex.date.UNIT.DAY );',
'todayPlus31.setHours(0,0,0,0);',
'',
'console.log(''The todays date plus 31 is: '' + todayPlus31);',
'// **replace P1_SHOW_HIDE_ITEM with YOUR item name  ',
'// **Compare input date and today date  ',
'',
'var isDateSame = apex.date.isSame( inputDate, todayDate);',
'var isDateSameAfter = apex.date.isSameOrAfter( inputDate, todayPlus31);',
'',
'var a = $v(''P4_SESSION'');',
'console.log(''Parsed value: '' + a);',
'if (isDateSameAfter == false)  {',
'',
'    $("#dissapear1").show();',
'    if (a == ''1'') {',
'    $("#U20_0").show(10);',
'    }',
'    if (a == ''2'') {',
'    $("#U20_15").show(10);',
'    }',
'    if (a == ''3'') {',
'    $("#U20_30").show(10);',
'    }',
'    $("#POP4").hide(10);',
'',
'} if (isDateSameAfter == true){',
'',
'    $("#U20_0").hide(10);',
'    $("#U20_15").hide(10);',
'    $("#U20_30").hide(10);',
'    $("#POP4").show(10);',
'}'))
);
wwv_flow_imp.component_end;
end;
/
