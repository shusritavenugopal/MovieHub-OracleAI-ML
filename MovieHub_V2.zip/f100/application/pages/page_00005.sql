prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7266698827421149
,p_default_application_id=>100
,p_default_id_offset=>8541228906651295
,p_default_owner=>'WKSP_HEATWAVE'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Halloween Movie --> Recommended Users'
,p_alias=>'HALLOWEEN-MOVIE-RECOMMENDED-USERS'
,p_step_title=>'Halloween Movie --> Recommended Users'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(16845437803600566)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-tags {',
'    list-style: lower-latin ;',
'}',
'.a-tag {',
'    background-color: #0b080e;',
'    color: rgb(248, 248, 248);',
'    border-radius: 8px;',
'    padding: 6px;',
'    margin: 5px;',
'    display: inline-flex;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(16844170522600560)
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'HEATWAVE'
,p_last_upd_yyyymmddhh24miss=>'20231025074701'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32265558306149666)
,p_plug_name=>'Movie Info'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16594788254600370)
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>3
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    q.Title,',
'    q.`Release Year`,',
'    TRIM('','' FROM q.Genres) AS Genres,',
'    u.url_down,',
'    u.legend',
'FROM (',
'    SELECT',
'        title AS ''Title'',',
'        release_year AS ''Release Year'',',
'        CONCAT(',
'            IF(genre_action = 1, CONCAT(''action,''), CONCAT('''')),',
'            IF(genre_adventure = 1, CONCAT(''adventure,''), CONCAT('''')),',
'            IF(genre_animation = 1, CONCAT(''animation,''), CONCAT('''')),',
'            IF(genre_children = 1, CONCAT(''children,''), CONCAT('''')),',
'            IF(genre_comedy = 1, CONCAT(''comedy,''), CONCAT('''')),',
'            IF(genre_crime = 1, CONCAT(''crime,''), CONCAT('''')),',
'            IF(genre_documentary = 1, CONCAT(''documentary,''), CONCAT('''')),',
'            IF(genre_drama = 1, CONCAT(''drama,''), ''''),',
'            IF(genre_fantasy = 1, CONCAT(''fantasy,''), CONCAT('''')),',
'            IF(genre_filmnoir = 1, CONCAT(''filmnoir,''), CONCAT('''')),',
'            IF(genre_horror = 1, CONCAT(''horror,''), CONCAT('''')),',
'            IF(genre_musical = 1, CONCAT(''musical,''), CONCAT('''')),',
'            IF(genre_mystery = 1, CONCAT(''mystery,''), CONCAT('''')),',
'            IF(genre_romance = 1, CONCAT(''romance,''), CONCAT('''')),',
'            IF(genre_scifi = 1, CONCAT(''scifi,''), CONCAT('''')),',
'            IF(genre_thriller = 1, CONCAT(''thriller,''), CONCAT('''')),',
'            IF(genre_unknown = 1, CONCAT(''unknown,''), CONCAT('''')),',
'            IF(genre_war = 1, CONCAT(''war,''), CONCAT('''')),',
'            IF(genre_western = 1, CONCAT(''western,''), CONCAT(''''))',
'        ) AS ''Genres'',',
'        item_id',
'    FROM movies.item',
'    WHERE item_id = 200',
') q',
'LEFT JOIN item_media u ON q.item_id = u.image_id;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(8621895508710782)
,p_region_id=>wwv_flow_imp.id(32265558306149666)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3><b>&"Title".</b></h3>'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'Release Year'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if Genres/}',
'    <ul class="a-tags">',
'    {loop "," Genres/}',
' 	    <li class="a-tag"><b>&APEX$ITEM.</li></b>',
'    {endloop/}',
'    </ul>',
'{endif/}'))
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<h4><b>&"legend".</b></h4>'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'url_down'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'Genres'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34083856731952826)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16670965546600409)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16555259918600334)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16733428132600444)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34084536388952827)
,p_plug_name=>'Movie 200 Recomended Users'
,p_icon_css_classes=>'fa-emoji-happy-smile'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16594788254600370)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>9
,p_plug_display_column=>4
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT u.user_id, u.user_age, u.user_gender, u.user_occupation, p.ml_results ',
'FROM user u INNER JOIN pred_item_200 p ON u.user_id = p.user_id order by ml_results desc limit 10;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_landmark_type=>'exclude_landmark'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(8622776260710783)
,p_region_id=>wwv_flow_imp.id(34084536388952827)
,p_layout_type=>'GRID'
,p_grid_column_count=>2
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h2> User ID:     &"user_id". '
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>'<h4> Occupation: &"user_occupation".<br>'
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<h4> AGE:  &"user_age".'
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'user_gender'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ml_results'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38424605799969180)
,p_name=>'P5_ACK'
,p_item_sequence=>10
,p_item_display_point=>'REGION_POSITION_05'
,p_use_cache_before_default=>'NO'
,p_prompt=>'acknowledgement'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'F. Maxwell Harper and Joseph A. Konstan. 2015. The MovieLens Datasets:',
'History and Context. ACM Transactions on Interactive Intelligent Systems (TiiS) 5, 4, Article 19 (December 2015), 19 pages.',
'DOI=http://dx.doi.org/10.1145/2827872'))
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(16729275947600439)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp.component_end;
end;
/
