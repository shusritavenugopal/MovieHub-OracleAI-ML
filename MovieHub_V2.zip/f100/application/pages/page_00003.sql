prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7266698827421149
,p_default_application_id=>100
,p_default_id_offset=>8541228906651295
,p_default_owner=>'WKSP_HEATWAVE'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Hello, James'
,p_alias=>'HELLO-JAMES'
,p_step_title=>'Hello, James'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-tags {',
'    list-style: none;',
'}',
'.a-tag {',
'    background-color: #0b080e;',
'    color: rgb(248, 248, 248);',
'    border-radius: 5px;',
'    padding: 5px;',
'    margin: 3px;',
'    display: inline;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'HEATWAVE'
,p_last_upd_yyyymmddhh24miss=>'20231025074605'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10385627259751200)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16670965546600409)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16555259918600334)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16733428132600444)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36276981085385470)
,p_plug_name=>'Recommended Movies For You'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16658618210600400)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32214480291884453)
,p_plug_name=>'User 21 + 0 Reviews'
,p_region_name=>'U21_0'
,p_parent_plug_id=>wwv_flow_imp.id(36276981085385470)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleA:js-headingLevel-1:t-Form--noPadding:t-Form--large:t-Form--leftLabels:t-Form--labelsAbove:margin-top-sm:margin-bottom-sm:margin-left-none:margin-right-none'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16594788254600370)
,p_plug_display_sequence=>30
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    q.item_id,',
'    q.Title,',
'    q.`Release Year`,',
'    TRIM('','' FROM q.Genres) AS Genres,',
'    m.user_id,',
'    m.ml_results AS ''Recommendation Rating'',',
'    u.url_down,',
'    i.legend',
'FROM movies.pred_user_21_0r m',
'JOIN (',
'    SELECT',
'        item_id,',
'        title AS ''Title'',',
'        release_year AS ''Release Year'',',
'        CONCAT(',
'            IF(genre_action = 1, CONCAT(''action,''), CONCAT('''')),',
'            IF(genre_adventure = 1, CONCAT(''adventure,''), CONCAT('''')),',
'            IF(genre_animation = 1, CONCAT(''animation,''), CONCAT('''')),',
'            IF(genre_children = 1, CONCAT(''children,''), CONCAT('''')),',
'            IF(genre_comedy = 1, CONCAT(''comedy,''), CONCAT('''')),',
'            IF(genre_crime = 1, CONCAT(''crime,''), CONCAT('''')),',
'            IF(genre_documentary = 1, CONCAT(''documentary,''), CONCAT('''')),',
'            IF(genre_drama = 1, CONCAT(''drama,''), ''''),',
'            IF(genre_fantasy = 1, CONCAT(''fantasy,''), CONCAT('''')),',
'            IF(genre_filmnoir = 1, CONCAT(''filmnoir,''), CONCAT('''')),',
'            IF(genre_horror = 1, CONCAT(''horror,''), CONCAT('''')),',
'            IF(genre_musical = 1, CONCAT(''musical,''), CONCAT('''')),',
'            IF(genre_mystery = 1, CONCAT(''mystery,''), CONCAT('''')),',
'            IF(genre_romance = 1, CONCAT(''romance,''), CONCAT('''')),',
'            IF(genre_scifi = 1, CONCAT(''scifi,''), CONCAT('''')),',
'            IF(genre_thriller = 1, CONCAT(''thriller,''), CONCAT('''')),',
'            IF(genre_unknown = 1, CONCAT(''unknown,''), CONCAT('''')),',
'            IF(genre_war = 1, CONCAT(''war,''), CONCAT('''')),',
'            IF(genre_western = 1, CONCAT(''western,''), CONCAT(''''))',
'        ) AS ''Genres''',
'    FROM movies.item',
') q ON m.item_id = q.item_id',
'JOIN item_media u ON m.item_id = u.image_id',
'JOIN (',
'    SELECT image_id, legend',
'    FROM item_media',
') i ON m.item_id = i.image_id',
'ORDER BY m.ml_results DESC, q.Title DESC',
'LIMIT 5;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(8576665592445593)
,p_region_id=>wwv_flow_imp.id(32214480291884453)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3><b>&"Title".</b></h3>'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'Release Year'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'{if Genres/}',
'    <ul class="a-tags">',
'    {loop "," Genres/}',
' 	    <li class="a-tag"><b>&APEX$ITEM.</li></b>',
'    {endloop/}',
'    </ul>',
'{endif/}',
'</br>'))
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<h4><b>&"legend".</b></h4>'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'url_down'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'Genres'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32214971490884457)
,p_plug_name=>'User 21 + 15 Reviews'
,p_region_name=>'U21_15'
,p_parent_plug_id=>wwv_flow_imp.id(36276981085385470)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleA:js-headingLevel-1:t-Form--noPadding:t-Form--large:t-Form--leftLabels:t-Form--labelsAbove:margin-top-sm:margin-bottom-sm:margin-left-none:margin-right-none'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16594788254600370)
,p_plug_display_sequence=>40
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    q.item_id,',
'    q.Title,',
'    q.`Release Year`,',
'    TRIM('','' FROM q.Genres) AS Genres,',
'    m.user_id,',
'    m.ml_results AS ''Recommendation Rating'',',
'    u.url_down,',
'    i.legend',
'FROM movies.pred_user_21_15r m',
'JOIN (',
'    SELECT',
'        item_id,',
'        title AS ''Title'',',
'        release_year AS ''Release Year'',',
'        CONCAT(',
'            IF(genre_action = 1, CONCAT(''action,''), CONCAT('''')),',
'            IF(genre_adventure = 1, CONCAT(''adventure,''), CONCAT('''')),',
'            IF(genre_animation = 1, CONCAT(''animation,''), CONCAT('''')),',
'            IF(genre_children = 1, CONCAT(''children,''), CONCAT('''')),',
'            IF(genre_comedy = 1, CONCAT(''comedy,''), CONCAT('''')),',
'            IF(genre_crime = 1, CONCAT(''crime,''), CONCAT('''')),',
'            IF(genre_documentary = 1, CONCAT(''documentary,''), CONCAT('''')),',
'            IF(genre_drama = 1, CONCAT(''drama,''), ''''),',
'            IF(genre_fantasy = 1, CONCAT(''fantasy,''), CONCAT('''')),',
'            IF(genre_filmnoir = 1, CONCAT(''filmnoir,''), CONCAT('''')),',
'            IF(genre_horror = 1, CONCAT(''horror,''), CONCAT('''')),',
'            IF(genre_musical = 1, CONCAT(''musical,''), CONCAT('''')),',
'            IF(genre_mystery = 1, CONCAT(''mystery,''), CONCAT('''')),',
'            IF(genre_romance = 1, CONCAT(''romance,''), CONCAT('''')),',
'            IF(genre_scifi = 1, CONCAT(''scifi,''), CONCAT('''')),',
'            IF(genre_thriller = 1, CONCAT(''thriller,''), CONCAT('''')),',
'            IF(genre_unknown = 1, CONCAT(''unknown,''), CONCAT('''')),',
'            IF(genre_war = 1, CONCAT(''war,''), CONCAT('''')),',
'            IF(genre_western = 1, CONCAT(''western,''), CONCAT(''''))',
'        ) AS ''Genres''',
'    FROM movies.item',
') q ON m.item_id = q.item_id',
'JOIN item_media u ON m.item_id = u.image_id',
'JOIN (',
'    SELECT image_id, legend',
'    FROM item_media',
') i ON m.item_id = i.image_id',
'ORDER BY m.ml_results DESC, q.Title DESC',
'LIMIT 5;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(8575807316445592)
,p_region_id=>wwv_flow_imp.id(32214971490884457)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3><b>&"Title".</b></h3>'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'Release Year'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'{if Genres/}',
'    <ul class="a-tags">',
'    {loop "," Genres/}',
' 	    <li class="a-tag"><b>&APEX$ITEM.</li></b>',
'    {endloop/}',
'    </ul>',
'{endif/}',
'</br>'))
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<h4><b>&"legend".</b></h4>'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'url_down'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'Recommendation Rating'
,p_pk2_column_name=>'Genres'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32215141691884459)
,p_plug_name=>'User 21 + 30 Reviews'
,p_region_name=>'U21_30'
,p_parent_plug_id=>wwv_flow_imp.id(36276981085385470)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleA:js-headingLevel-1:t-Form--noPadding:t-Form--large:t-Form--leftLabels:t-Form--labelsAbove:margin-top-sm:margin-bottom-sm:margin-left-none:margin-right-none'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16594788254600370)
,p_plug_display_sequence=>50
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    q.item_id,',
'    q.Title,',
'    q.`Release Year`,',
'    TRIM('','' FROM q.Genres) AS Genres,',
'    m.user_id,',
'    m.ml_results AS ''Recommendation Rating'',',
'    u.url_down,',
'    i.legend',
'FROM movies.pred_user_21_30r m',
'JOIN (',
'    SELECT',
'        item_id,',
'        title AS ''Title'',',
'        release_year AS ''Release Year'',',
'        CONCAT(',
'            IF(genre_action = 1, CONCAT(''action,''), CONCAT('''')),',
'            IF(genre_adventure = 1, CONCAT(''adventure,''), CONCAT('''')),',
'            IF(genre_animation = 1, CONCAT(''animation,''), CONCAT('''')),',
'            IF(genre_children = 1, CONCAT(''children,''), CONCAT('''')),',
'            IF(genre_comedy = 1, CONCAT(''comedy,''), CONCAT('''')),',
'            IF(genre_crime = 1, CONCAT(''crime,''), CONCAT('''')),',
'            IF(genre_documentary = 1, CONCAT(''documentary,''), CONCAT('''')),',
'            IF(genre_drama = 1, CONCAT(''drama,''), ''''),',
'            IF(genre_fantasy = 1, CONCAT(''fantasy,''), CONCAT('''')),',
'            IF(genre_filmnoir = 1, CONCAT(''filmnoir,''), CONCAT('''')),',
'            IF(genre_horror = 1, CONCAT(''horror,''), CONCAT('''')),',
'            IF(genre_musical = 1, CONCAT(''musical,''), CONCAT('''')),',
'            IF(genre_mystery = 1, CONCAT(''mystery,''), CONCAT('''')),',
'            IF(genre_romance = 1, CONCAT(''romance,''), CONCAT('''')),',
'            IF(genre_scifi = 1, CONCAT(''scifi,''), CONCAT('''')),',
'            IF(genre_thriller = 1, CONCAT(''thriller,''), CONCAT('''')),',
'            IF(genre_unknown = 1, CONCAT(''unknown,''), CONCAT('''')),',
'            IF(genre_war = 1, CONCAT(''war,''), CONCAT('''')),',
'            IF(genre_western = 1, CONCAT(''western,''), CONCAT(''''))',
'        ) AS ''Genres''',
'    FROM movies.item',
') q ON m.item_id = q.item_id',
'JOIN item_media u ON m.item_id = u.image_id',
'JOIN (',
'    SELECT image_id, legend',
'    FROM item_media',
') i ON m.item_id = i.image_id',
'ORDER BY m.ml_results DESC, q.Title DESC',
'LIMIT 5;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(8577632411445594)
,p_region_id=>wwv_flow_imp.id(32215141691884459)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3><b>&"Title".</b></h3>'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'Release Year'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'{if Genres/}',
'    <ul class="a-tags">',
'    {loop "," Genres/}',
' 	    <li class="a-tag"><b>&APEX$ITEM.</li></b>',
'    {endloop/}',
'    </ul>',
'{endif/}',
'</br>'))
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<h4><b>&"legend".</b></h4>'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'url_down'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'Genres'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47356709968615246)
,p_plug_name=>'Popular Movies'
,p_region_name=>'POP3'
,p_parent_plug_id=>wwv_flow_imp.id(36276981085385470)
,p_region_template_options=>'u-colors:t-CardsRegion--styleA:js-headingLevel-1:t-Form--slimPadding:t-Form--large:t-Form--leftLabels:t-Form--labelsAbove:t-Region-orderBy--center'
,p_plug_template=>wwv_flow_imp.id(16594788254600370)
,p_plug_display_sequence=>60
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    q.item_id,',
'    q.Title,',
'    q.`Release Year`,',
'    TRIM('','' FROM q.Genres) AS Genres,',
'    m.user_id,',
'    m.ml_results AS ''Recommendation Rating'',',
'    u.url_down,',
'    i.legend',
'FROM movies.pred_user_new_30r m',
'JOIN (',
'    SELECT',
'        item_id,',
'        title AS ''Title'',',
'        release_year AS ''Release Year'',',
'        CONCAT(',
'            IF(genre_action = 1, CONCAT(''action,''), CONCAT('''')),',
'            IF(genre_adventure = 1, CONCAT(''adventure,''), CONCAT('''')),',
'            IF(genre_animation = 1, CONCAT(''animation,''), CONCAT('''')),',
'            IF(genre_children = 1, CONCAT(''children,''), CONCAT('''')),',
'            IF(genre_comedy = 1, CONCAT(''comedy,''), CONCAT('''')),',
'            IF(genre_crime = 1, CONCAT(''crime,''), CONCAT('''')),',
'            IF(genre_documentary = 1, CONCAT(''documentary,''), CONCAT('''')),',
'            IF(genre_drama = 1, CONCAT(''drama,''), ''''),',
'            IF(genre_fantasy = 1, CONCAT(''fantasy,''), CONCAT('''')),',
'            IF(genre_filmnoir = 1, CONCAT(''filmnoir,''), CONCAT('''')),',
'            IF(genre_horror = 1, CONCAT(''horror,''), CONCAT('''')),',
'            IF(genre_musical = 1, CONCAT(''musical,''), CONCAT('''')),',
'            IF(genre_mystery = 1, CONCAT(''mystery,''), CONCAT('''')),',
'            IF(genre_romance = 1, CONCAT(''romance,''), CONCAT('''')),',
'            IF(genre_scifi = 1, CONCAT(''scifi,''), CONCAT('''')),',
'            IF(genre_thriller = 1, CONCAT(''thriller,''), CONCAT('''')),',
'            IF(genre_unknown = 1, CONCAT(''unknown,''), CONCAT('''')),',
'            IF(genre_war = 1, CONCAT(''war,''), CONCAT('''')),',
'            IF(genre_western = 1, CONCAT(''western,''), CONCAT(''''))',
'        ) AS ''Genres''',
'    FROM movies.item',
') q ON m.item_id = q.item_id',
'JOIN item_media u ON m.item_id = u.image_id',
'JOIN (',
'    SELECT image_id, legend',
'    FROM item_media',
') i ON m.item_id = i.image_id',
'ORDER BY m.ml_results DESC, q.Title DESC',
'LIMIT 5;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(8578522258445595)
,p_region_id=>wwv_flow_imp.id(47356709968615246)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3><b>&"Title".</b></h3>'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'Release Year'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'{if Genres/}',
'    <ul class="a-tags">',
'    {loop "," Genres/}',
' 	    <li class="a-tag"><b>&APEX$ITEM.</li></b>',
'    {endloop/}',
'    </ul>',
'{endif/}',
'</br>'))
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<h4><b>&"legend".</b></h4>'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'url_down'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'Genres'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8572886321445586)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(36276981085385470)
,p_button_name=>'LOGOUT21'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--warning:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(16731741709600443)
,p_button_is_hot=>'Y'
,p_button_image_alt=>']-> Profiles'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8573293180445587)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(36276981085385470)
,p_button_name=>'ADD15'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16731741709600443)
,p_button_image_alt=>'Watch 15 Movies'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8573671547445587)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(36276981085385470)
,p_button_name=>'ADD30'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16731741709600443)
,p_button_image_alt=>'Watch 30 Movies'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8574159945445588)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(36276981085385470)
,p_button_name=>'Restore'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16731741709600443)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Restore'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36279765486385476)
,p_name=>'DATE_3'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(36276981085385470)
,p_item_display_point=>'EDIT'
,p_item_default=>'SELECT TO_CHAR(sysdate, ''YYYY-MM-DD'') FROM dual;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Login Date'
,p_format_mask=>'YYYY-MM-DD'
,p_source=>'SELECT TO_CHAR(sysdate, ''YYYY-MM-DD'') FROM dual;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16729275947600439)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'NATIVE'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'P3_SYSDATE'
,p_attribute_06=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37752413539607244)
,p_name=>'P3_SESSION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(36276981085385470)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37753442702607255)
,p_name=>'P3_SYSDATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(36276981085385470)
,p_item_display_point=>'EDIT'
,p_use_cache_before_default=>'NO'
,p_item_default=>'SELECT TO_CHAR(sysdate, ''YYYY-MM-DD'') FROM dual;'
,p_item_default_type=>'SQL_QUERY'
,p_source=>'SELECT TO_CHAR(sysdate, ''YYYY-MM-DD'') FROM dual;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38379820592703989)
,p_name=>'P3_ACK'
,p_item_sequence=>20
,p_item_display_point=>'REGION_POSITION_05'
,p_use_cache_before_default=>'NO'
,p_prompt=>'Acknowledgement'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'F. Maxwell Harper and Joseph A. Konstan. 2015. The MovieLens Datasets:',
'History and Context. ACM Transactions on Interactive Intelligent Systems (TiiS) 5, 4, Article 19 (December 2015), 19 pages.',
'DOI=http://dx.doi.org/10.1145/2827872'))
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(16729275947600439)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8579851343445598)
,p_name=>'add 15'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8573293180445587)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8580292604445600)
,p_event_id=>wwv_flow_imp.id(8579851343445598)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#U21_0").hide(10);',
'$("#U21_30").hide(10);',
'$("#U21_15").show(10);',
'$("#POP3").hide(10);',
'var sessionState = 3;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8580684091445601)
,p_name=>'add 30'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8573671547445587)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8581234054445601)
,p_event_id=>wwv_flow_imp.id(8580684091445601)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#U21_0").hide(10);',
'$("#U21_15").hide(10);',
'$("#U21_30").show(10);',
'$("#POP3").hide(10);',
'var sessionState = 2;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8581655099445602)
,p_name=>'Restore'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8574159945445588)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8582151141445602)
,p_event_id=>wwv_flow_imp.id(8581655099445602)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#U21_15").hide(10);',
'$("#U21_30").hide(10);',
'$("#U21_0").show(10);',
'$("#POP3").hide(10);',
'var sessionState = 1;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8582461092445602)
,p_name=>'restore'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8583035356445603)
,p_event_id=>wwv_flow_imp.id(8582461092445602)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#U21_15").hide(10);',
'$("#U21_30").hide(10);',
'$("#U21_0").show(10);',
'$("#POP3").hide(10);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8583395795445603)
,p_name=>'New'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'DATE_3'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8583909343445603)
,p_event_id=>wwv_flow_imp.id(8583395795445603)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// **Get the date string from the input type',
'',
'var itemVal = $v(''DATE_3'');',
'//var itemVal = "2023-09-26"',
'',
'// **Get the various element of the date ie year, month and date',
'',
'',
'var year = itemVal.substring(0,4);  ',
'',
'var month = itemVal.substring(5,7);  ',
'',
'var day = itemVal.substring(8,10);',
'',
'// **Construct JS Date Object  ',
'console.log(''The DatePicked date is: '' + itemVal);',
'console.log(''The year date is: '' + year);',
'console.log(''The month date is: '' + month);',
'console.log(''The day date is: '' + day);',
'',
'var inputDate =new Date();  ',
'',
'inputDate.setFullYear(year,month-1,day);  //Months in javascript start from 0',
'',
'inputDate.setHours(0,0,0,0);',
'',
'console.log(''The input date is: '' + inputDate);',
'// **Get todays date, as Date Object  ',
'',
'var todayDate = new Date(); ',
'',
'todayDate.setHours(0,0,0,0);',
'',
'console.log(''The todays date is: '' + todayDate);',
'',
'var todayPlus31 =new Date();  ',
'',
'todayPlus31 = apex.date.add( todayPlus31, 31, apex.date.UNIT.DAY );',
'todayPlus31.setHours(0,0,0,0);',
'',
'console.log(''The todays date plus 31 is: '' + todayPlus31);',
'// **replace P1_SHOW_HIDE_ITEM with YOUR item name  ',
'// **Compare input date and today date  ',
'',
'var isDateSame = apex.date.isSame( inputDate, todayDate);',
'var isDateSameAfter = apex.date.isSameOrAfter( inputDate, todayPlus31);',
'',
'var a = $v(''P3_SESSION'');',
'console.log(''Parsed value: '' + a);',
'if (isDateSameAfter == false)  {',
'',
'    $("#dissapear1").show();',
'    if (a == ''1'') {',
'    $("#U21_0").show(10);',
'    }',
'    if (a == ''2'') {',
'    $("#U21_15").show(10);',
'    }',
'    if (a == ''3'') {',
'    $("#U21_30").show(10);',
'    }',
'    $("#POP3").hide(10);',
'',
'} if (isDateSameAfter == true){',
'',
'    $("#U21_0").hide(10);',
'    $("#U21_15").hide(10);',
'    $("#U21_30").hide(10);',
'    $("#POP3").show(10);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8584348247445604)
,p_name=>'session2'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8573293180445587)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8584854772445604)
,p_event_id=>wwv_flow_imp.id(8584348247445604)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_SESSION'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'2'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8585169557445604)
,p_name=>'session3'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8573671547445587)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8585760059445605)
,p_event_id=>wwv_flow_imp.id(8585169557445604)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_SESSION'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'3'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8586062712445605)
,p_name=>'session1'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8574159945445588)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8586562850445605)
,p_event_id=>wwv_flow_imp.id(8586062712445605)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_SESSION'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
