prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7266698827421149
,p_default_application_id=>100
,p_default_id_offset=>8541228906651295
,p_default_owner=>'WKSP_HEATWAVE'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Analytics Dashboard'
,p_alias=>'ANALYTICS-DASHBOARD1'
,p_step_title=>'Analytics Dashboard'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(16845437803600566)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(16844170522600560)
,p_protection_level=>'C'
,p_page_component_map=>'04'
,p_last_updated_by=>'HEATWAVE'
,p_last_upd_yyyymmddhh24miss=>'20231020193527'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38428422434003600)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16670965546600409)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16555259918600334)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16733428132600444)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49129215453352665)
,p_plug_name=>'Movies -  Genres Distribution'
,p_region_template_options=>'#DEFAULT#:t-Region--accent7:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16658618210600400)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(8632778351745223)
,p_region_id=>wwv_flow_imp.id(49129215453352665)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(8633350462745224)
,p_chart_id=>wwv_flow_imp.id(8632778351745223)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ''genre_action'' AS Genres,',
'    SUM(genre_action) AS count,',
'    AVG(genre_action) AS avgerage,',
'    (SUM(genre_action) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_adventure'' AS Genres,',
'    SUM(genre_adventure) AS count,',
'    AVG(genre_adventure) AS avgerage,',
'    (SUM(genre_adventure) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_animation'' AS Genres,',
'    SUM(genre_animation) AS count,',
'    AVG(genre_animation) AS avgerage,',
'    (SUM(genre_animation) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_children'' AS Genres,',
'    SUM(genre_children) AS count,',
'    AVG(genre_children) AS avgerage,',
'    (SUM(genre_children) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_comedy'' AS Genres,',
'    SUM(genre_comedy) AS count,',
'    AVG(genre_comedy) AS avgerage,',
'    (SUM(genre_comedy) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_crime'' AS Genres,',
'    SUM(genre_crime) AS count,',
'    AVG(genre_crime) AS avgerage,',
'    (SUM(genre_crime) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_documentary'' AS Genres,',
'    SUM(genre_documentary) AS count,',
'    AVG(genre_documentary) AS avgerage,',
'    (SUM(genre_documentary) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_drama'' AS Genres,',
'    SUM(genre_drama) AS count,',
'    AVG(genre_drama) AS avgerage,',
'    (SUM(genre_drama) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_fantasy'' AS Genres,',
'    SUM(genre_fantasy) AS count,',
'    AVG(genre_fantasy) AS avgerage,',
'    (SUM(genre_fantasy) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_filmnoir'' AS Genres,',
'    SUM(genre_filmnoir) AS count,',
'    AVG(genre_filmnoir) AS avgerage,',
'    (SUM(genre_filmnoir) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_horror'' AS Genres,',
'    SUM(genre_horror) AS count,',
'    AVG(genre_horror) AS avgerage,',
'    (SUM(genre_horror) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_musical'' AS Genres,',
'    SUM(genre_musical) AS count,',
'    AVG(genre_musical) AS avgerage,',
'    (SUM(genre_musical) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_mystery'' AS Genres,',
'    SUM(genre_mystery) AS count,',
'    AVG(genre_mystery) AS avgerage,',
'    (SUM(genre_mystery) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_romance'' AS Genres,',
'    SUM(genre_romance) AS count,',
'    AVG(genre_romance) AS avgerage,',
'    (SUM(genre_romance) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_scifi'' AS Genres,',
'    SUM(genre_scifi) AS count,',
'    AVG(genre_scifi) AS avgerage,',
'    (SUM(genre_scifi) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_thriller'' AS Genres,',
'    SUM(genre_thriller) AS count,',
'    AVG(genre_thriller) AS avgerage,',
'    (SUM(genre_thriller) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_unknown'' AS Genres,',
'    SUM(genre_unknown) AS count,',
'    AVG(genre_unknown) AS avgerage,',
'    (SUM(genre_unknown) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_war'' AS Genres,',
'    SUM(genre_war) AS count,',
'    AVG(genre_war) AS avgerage,',
'    (SUM(genre_war) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'UNION ALL',
'SELECT',
'    ''genre_western'' AS Genres,',
'    SUM(genre_western) AS count,',
'    AVG(genre_western) AS avgerage,',
'    (SUM(genre_western) / COUNT(*)) * 100 AS Percentage',
'FROM movies.item',
'ORDER BY Genres;',
''))
,p_max_row_count=>20
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_series_name_column_name=>'Genres'
,p_items_value_column_name=>'Percentage'
,p_items_label_column_name=>'Genres'
,p_items_short_desc_column_name=>'count'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LBL_PCT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49131837273352674)
,p_plug_name=>'Users  - Gender Distribution'
,p_region_template_options=>'#DEFAULT#:t-Region--accent7:t-Region--noBorder:t-Region--scrollBody:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(16658618210600400)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(8629223733745216)
,p_region_id=>wwv_flow_imp.id(49131837273352674)
,p_chart_type=>'donut'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlightAndExplode'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(8631456478745220)
,p_chart_id=>wwv_flow_imp.id(8629223733745216)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT user_gender, ',
'COUNT(*) AS user_count, ',
'(COUNT(*) / (SELECT COUNT(*) ',
'FROM movies.user)) * 100 AS gender_percentage ',
'FROM movies.user ',
'GROUP BY user_gender;'))
,p_max_row_count=>20
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_series_name_column_name=>'user_gender'
,p_items_value_column_name=>'gender_percentage'
,p_items_label_column_name=>'user_gender'
,p_items_short_desc_column_name=>'user_count'
,p_custom_column_name=>'gender_percentage'
,p_items_label_rendered=>true
,p_items_label_position=>'outsideBarEdge'
,p_items_label_display_as=>'LBL_PCT'
,p_items_label_font_family=>'Georgia'
,p_items_label_font_style=>'normal'
,p_items_label_font_size=>'18'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49133361223352675)
,p_plug_name=>'Users - Age Distribution'
,p_region_template_options=>'#DEFAULT#:t-Region--accent7:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16658618210600400)
,p_plug_display_sequence=>30
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(8634268449745225)
,p_region_id=>wwv_flow_imp.id(49133361223352675)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'N'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(8636005481745226)
,p_chart_id=>wwv_flow_imp.id(8634268449745225)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CASE',
'        WHEN user_age <= 14 THEN ''14<''',
'        WHEN user_age > 14 AND user_age <= 25 THEN ''15-25''',
'        WHEN user_age > 25 AND user_age <= 45 THEN ''26-45''',
'        ELSE ''45>''',
'    END AS age_range,',
'    COUNT(*) AS user_count,',
'    (COUNT(*) / (SELECT COUNT(*) FROM movies.user)) * 100 AS age_percentage',
'FROM movies.user',
'GROUP BY age_range;'))
,p_max_row_count=>20
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_series_name_column_name=>'age_range'
,p_items_value_column_name=>'age_percentage'
,p_items_label_column_name=>'age_range'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(8634771785745225)
,p_chart_id=>wwv_flow_imp.id(8634268449745225)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(8635386089745226)
,p_chart_id=>wwv_flow_imp.id(8634268449745225)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Percentage'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49136015884352677)
,p_plug_name=>'Top 10 Trending Movies'
,p_region_template_options=>'#DEFAULT#:t-Region--accent7:t-Region--noBorder:t-Region--scrollBody:t-Form--standardPadding'
,p_plug_template=>wwv_flow_imp.id(16658618210600400)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(8636988526745227)
,p_region_id=>wwv_flow_imp.id(49136015884352677)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'value-desc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(8638713257745228)
,p_chart_id=>wwv_flow_imp.id(8636988526745227)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    t0.item_id,',
'    i.title,',
'    CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(t30.ml_results, ''"rating":'', -1), ''}'', 1) -',
'          SUBSTRING_INDEX(SUBSTRING_INDEX(t0.ml_results, ''"rating":'', -1), ''}'', 1) AS DECIMAL(10, 2)) AS rating_change',
'FROM ',
'    movies.pred_user_new_0r AS t0',
'JOIN ',
'    movies.pred_user_new_30r AS t30 ON t0.item_id = t30.item_id',
'JOIN',
'    movies.item AS i ON t0.item_id = i.item_id',
'ORDER BY ',
'    rating_change DESC',
'LIMIT 10;',
''))
,p_max_row_count=>20
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_imp.id(17064182168279363)
,p_series_name_column_name=>'rating_change'
,p_items_value_column_name=>'rating_change'
,p_items_label_column_name=>'title'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(8637490311745227)
,p_chart_id=>wwv_flow_imp.id(8636988526745227)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(8638093519745227)
,p_chart_id=>wwv_flow_imp.id(8636988526745227)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Rating Change'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp.component_end;
end;
/
