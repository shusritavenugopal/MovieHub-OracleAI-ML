prompt --workspace/credentials/moviehub_credentials
begin
--   Manifest
--     CREDENTIAL: MovieHub-credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7266698827421149
,p_default_application_id=>100
,p_default_id_offset=>8541228906651295
,p_default_owner=>'WKSP_HEATWAVE'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(7268969782615705)
,p_name=>'MovieHub-credentials'
,p_static_id=>'MovieHub_credentials'
,p_authentication_type=>'OCI'
,p_namespace=>'ocid1.tenancy.oc1..aaaaaaaa4yet6xypq5khquqhozb7rja2cwomj4zvpxvqgusrnojr3t5rieiq'
,p_valid_for_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://sql.dbtools.mx-queretaro-1.oci.oraclecloud.com/20201005/ords/ocid1.databasetoolsconnection.oc1.mx-queretaro-1.amaaaaaacicuulya5ogj6fzkqyqcb5ecba6u4bhqtqocytyvj6ix3y6aci7a/_/sql',
''))
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
